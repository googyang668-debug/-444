
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { TreeConfig, TreeState } from "../types";

export const treeControlSchema: FunctionDeclaration = {
  name: 'updateTreeAesthetics',
  parameters: {
    type: Type.OBJECT,
    description: 'Update the visual parameters or state of the Christmas tree.',
    properties: {
      state: {
        type: Type.STRING,
        enum: ['SCATTERED', 'TREE_SHAPE'],
        description: 'The physical arrangement of the tree elements.',
      },
      glowAmount: {
        type: Type.NUMBER,
        description: 'The intensity of the cinematic glow (0.0 to 2.0).',
      },
      starColor: {
        type: Type.STRING,
        description: 'The hex color of the top star.',
      },
      rotationSpeed: {
        type: Type.NUMBER,
        description: 'How fast the tree rotates.',
      }
    },
  },
};

export const getArixResponse = async (userPrompt: string, currentConfig: TreeConfig) => {
  // Use a fresh instance to ensure we use the latest injected key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `The user says: "${userPrompt}". 
    Current status: State is ${currentConfig.state}, Glow is ${currentConfig.glowAmount}, Star is ${currentConfig.starColor}.
    
    You are "Arix", the luxury concierge for this Signature Interactive Christmas Tree experience. 
    You have the power to "manifest" changes. If the user asks for magic, to scatter the tree, or to light it up, use the updateTreeAesthetics tool.
    Your tone: extremely sophisticated, poetic, and high-class.`,
    config: {
      systemInstruction: "You are Arix, a luxury AI concierge. Use function calling to modify the tree when requested.",
      tools: [{ functionDeclarations: [treeControlSchema] }],
    }
  });

  return response;
};
