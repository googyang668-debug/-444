
import React from 'react';
import { TreeConfig } from '../types';
import { Settings, Sparkles, Box, LayoutGrid } from 'lucide-react';

interface UIOverlayProps {
  config: TreeConfig;
  setConfig: React.Dispatch<React.SetStateAction<TreeConfig>>;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ config, setConfig }) => {
  const updateConfig = (key: keyof TreeConfig, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const toggleState = () => {
    updateConfig('state', config.state === 'TREE_SHAPE' ? 'SCATTERED' : 'TREE_SHAPE');
  };

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none flex flex-col justify-between p-10 z-10">
      {/* Header */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="animate-in slide-in-from-top-4 duration-1000">
          <h1 className="text-5xl md:text-7xl font-black gold-text mb-2 uppercase tracking-[-0.05em] leading-none">
            Merry Christmas
          </h1>
          <div className="flex items-center gap-3">
            <div className="h-[1px] w-12 bg-gold-500/40" />
            <p className="text-emerald-300/60 font-serif italic text-xl tracking-wide">
              Shumei love u
            </p>
          </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <button 
             onClick={toggleState}
             className="bg-black/60 backdrop-blur-xl border border-gold-500/30 p-5 rounded-2xl flex items-center gap-3 text-gold-400 hover:text-gold-200 transition-all hover:shadow-[0_0_20px_rgba(191,149,63,0.2)] group"
           >
             {config.state === 'TREE_SHAPE' ? <Box size={24} /> : <LayoutGrid size={24} />}
             <span className="font-bold text-xs uppercase tracking-[0.3em] hidden md:inline">
               {config.state === 'TREE_SHAPE' ? 'Scatter' : 'Assemble'}
             </span>
           </button>
        </div>
      </div>

      {/* Designer Dashboard */}
      <div className="flex flex-col md:flex-row gap-8 justify-between items-end pointer-events-auto animate-in fade-in slide-in-from-bottom-4 duration-1000">
        <div className="bg-black/70 backdrop-blur-2xl border border-gold-500/20 p-8 rounded-[2.5rem] w-full md:w-96 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)]">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3 text-gold-400">
              <Settings size={20} />
              <h3 className="font-bold text-[10px] uppercase tracking-[0.4em] text-emerald-200/50">Aesthetic Parameters</h3>
            </div>
            <div className="px-3 py-1 bg-gold-500/10 border border-gold-500/20 rounded-full">
               <span className="text-[10px] text-gold-400 font-bold uppercase tracking-widest">Live</span>
            </div>
          </div>
          
          <div className="space-y-8">
            <div className="group">
              <div className="flex justify-between text-[10px] mb-3 uppercase tracking-widest text-emerald-400/60 group-hover:text-gold-400 transition-colors">
                <span>Gold Lustre</span>
                <span>{Math.round(config.goldLustre * 100)}%</span>
              </div>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={config.goldLustre} 
                onChange={(e) => updateConfig('goldLustre', parseFloat(e.target.value))}
                className="w-full accent-gold-500 bg-emerald-950 rounded-full appearance-none h-1 cursor-pointer"
              />
            </div>

            <div className="group">
              <div className="flex justify-between text-[10px] mb-3 uppercase tracking-widest text-emerald-400/60 group-hover:text-gold-400 transition-colors">
                <span>Cinematic Bloom</span>
                <span>{Math.round(config.glowAmount * 100)}%</span>
              </div>
              <input 
                type="range" min="0" max="2" step="0.01" 
                value={config.glowAmount} 
                onChange={(e) => updateConfig('glowAmount', parseFloat(e.target.value))}
                className="w-full accent-gold-500 bg-emerald-950 rounded-full appearance-none h-1 cursor-pointer"
              />
            </div>

            <div className="group">
              <div className="flex justify-between text-[10px] mb-3 uppercase tracking-widest text-emerald-400/60 group-hover:text-gold-400 transition-colors">
                <span>Spin Velocity</span>
                <span>{Math.round(config.rotationSpeed * 100)}%</span>
              </div>
              <input 
                type="range" min="0" max="3" step="0.1" 
                value={config.rotationSpeed} 
                onChange={(e) => updateConfig('rotationSpeed', parseFloat(e.target.value))}
                className="w-full accent-gold-500 bg-emerald-950 rounded-full appearance-none h-1 cursor-pointer"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4 items-end">
          <span className="text-[10px] uppercase tracking-[0.5em] text-emerald-500/50 mb-2">Color Palette</span>
          <div className="flex gap-4 p-2 bg-black/40 backdrop-blur-md border border-white/5 rounded-full">
            {['#FFD700', '#FFFFFF', '#00ff88', '#FF4444'].map(color => (
              <button 
                key={color}
                onClick={() => updateConfig('starColor', color)}
                className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-125 ${config.starColor === color ? 'border-white' : 'border-transparent'}`}
                style={{ backgroundColor: color, boxShadow: config.starColor === color ? `0 0 15px ${color}` : 'none' }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UIOverlay;
