
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, X } from 'lucide-react';
import { getArixResponse } from '../services/geminiService';
import { ChatMessage, TreeConfig } from '../types';

interface ArixAssistantProps {
  config: TreeConfig;
  setConfig: React.Dispatch<React.SetStateAction<TreeConfig>>;
}

const ArixAssistant: React.FC<ArixAssistantProps> = ({ config, setConfig }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: 'Good evening. I am Arix. How shall we manifest your holiday vision today?', timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg: ChatMessage = { role: 'user', content: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await getArixResponse(input, config);
      
      // Handle tool calls
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.functionCall && part.functionCall.name === 'updateTreeAesthetics') {
            const args = part.functionCall.args as any;
            setConfig(prev => ({
              ...prev,
              ...(args.state && { state: args.state }),
              ...(args.glowAmount !== undefined && { glowAmount: args.glowAmount }),
              ...(args.starColor && { starColor: args.starColor }),
              ...(args.rotationSpeed !== undefined && { rotationSpeed: args.rotationSpeed }),
            }));
          }
        }
      }

      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: response.text || "The festive energies are shifting as you requested.", 
        timestamp: Date.now() 
      }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'assistant', content: "My apologies, a momentary shimmer in the digital fabric.", timestamp: Date.now() }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed top-8 right-8 z-50 pointer-events-auto">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-emerald-950/90 backdrop-blur-xl p-5 rounded-full border border-gold-500/40 shadow-[0_0_30px_rgba(191,149,63,0.3)] hover:scale-110 transition-all group"
        >
          <Sparkles className="text-gold-400 group-hover:text-gold-200" size={28} />
        </button>
      ) : (
        <div className="w-80 md:w-[400px] h-[550px] bg-emerald-950/95 backdrop-blur-3xl border border-gold-500/30 rounded-[2rem] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
          <div className="p-6 border-b border-gold-500/10 flex justify-between items-center bg-white/5">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-gold-400 animate-pulse shadow-[0_0_10px_#FFD700]" />
              <span className="font-bold gold-text uppercase tracking-[0.2em] text-xs">Arix Concierge</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-emerald-300 hover:text-white transition-colors">
              <X size={20} />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-4 rounded-3xl text-sm leading-relaxed ${
                  msg.role === 'user' 
                  ? 'bg-emerald-800/80 text-white rounded-br-none border border-white/10 shadow-lg' 
                  : 'bg-black/40 text-emerald-50 border border-gold-500/10 rounded-bl-none italic font-serif'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-black/40 p-4 rounded-3xl rounded-bl-none border border-gold-500/5">
                  <div className="flex gap-1.5">
                    <div className="w-1 h-1 bg-gold-500/60 rounded-full animate-bounce" />
                    <div className="w-1 h-1 bg-gold-500/60 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1 h-1 bg-gold-500/60 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 bg-black/30 border-t border-gold-500/10">
            <div className="relative group">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Compose a request..."
                className="w-full bg-emerald-900/30 border border-gold-500/20 rounded-2xl py-4 px-5 text-emerald-50 pr-14 focus:outline-none focus:border-gold-500/50 focus:bg-emerald-900/50 transition-all placeholder:text-emerald-700/50"
              />
              <button 
                onClick={handleSend}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-3 text-gold-400 hover:text-gold-200 transition-all hover:scale-110"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ArixAssistant;
