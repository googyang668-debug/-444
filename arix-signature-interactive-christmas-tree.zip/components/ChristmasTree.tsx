
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float, Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { TreeConfig } from '../types';

interface ChristmasTreeProps {
  config: TreeConfig;
}

// Custom Shader for high-fidelity foliage morphing
const FoliageShader = {
  uniforms: {
    uTime: { value: 0 },
    uMorph: { value: 1 },
    uGlow: { value: 1.2 },
    uColor: { value: new THREE.Color('#064e3b') },
    uGold: { value: new THREE.Color('#bf953f') },
  },
  vertexShader: `
    uniform float uTime;
    uniform float uMorph;
    attribute vec3 aTreePos;
    attribute vec3 aScatterPos;
    attribute float aSize;
    attribute float aOffset;
    varying float vGlow;

    void main() {
      // Morph between scattered and tree shape
      vec3 pos = mix(aScatterPos, aTreePos, uMorph);
      
      // Add breathing/vibration effect
      float wave = sin(uTime * 2.0 + aOffset) * 0.02;
      pos += wave * (1.0 - uMorph * 0.8);

      vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
      gl_PointSize = aSize * (300.0 / -mvPosition.z);
      gl_Position = projectionMatrix * mvPosition;
      
      vGlow = pow(1.0 - abs(sin(aOffset + uTime * 0.5)), 3.0);
    }
  `,
  fragmentShader: `
    uniform vec3 uColor;
    uniform vec3 uGold;
    uniform float uGlow;
    varying float vGlow;

    void main() {
      float dist = distance(gl_PointCoord, vec2(0.5));
      if (dist > 0.5) discard;
      float alpha = smoothstep(0.5, 0.4, dist);
      vec3 color = mix(uColor, uGold, vGlow * 0.4);
      gl_FragColor = vec4(color * (1.0 + vGlow * uGlow), alpha * 0.8);
    }
  `
};

const ChristmasTree: React.FC<ChristmasTreeProps> = ({ config }) => {
  const groupRef = useRef<THREE.Group>(null!);
  const foliageRef = useRef<THREE.Points>(null!);
  const morphFactor = useRef(config.state === 'TREE_SHAPE' ? 1 : 0);
  
  const foliageCount = 15000;
  const foliageAttributes = useMemo(() => {
    const treePos = new Float32Array(foliageCount * 3);
    const scatterPos = new Float32Array(foliageCount * 3);
    const sizes = new Float32Array(foliageCount);
    const offsets = new Float32Array(foliageCount);
    
    for (let i = 0; i < foliageCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const height = u * 6.5;
      const radiusAtHeight = (1.0 - u * 0.95) * 2.8;
      const angle = v * Math.PI * 2;
      
      treePos[i * 3] = Math.cos(angle) * radiusAtHeight;
      treePos[i * 3 + 1] = height;
      treePos[i * 3 + 2] = Math.sin(angle) * radiusAtHeight;
      
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 10 + Math.random() * 8;
      scatterPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      scatterPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) + 3;
      scatterPos[i * 3 + 2] = r * Math.cos(phi);

      sizes[i] = Math.random() * 0.12 + 0.04;
      offsets[i] = Math.random() * 100;
    }
    return { treePos, scatterPos, sizes, offsets };
  }, []);

  // --- ORNAMENT SYSTEM (OPTIMIZED INSTANCED MESH) ---
  const categories = useMemo(() => [
    { name: 'bauble', count: 80, weight: 0.8, color: '#FFD700', size: 0.15 },
    { name: 'star', count: 40, weight: 1.5, color: '#E2E8F0', size: 0.12 },
    { name: 'gift', count: 15, weight: 0.4, color: '#FFFFFF', size: 0.4 },
    { 
      name: 'raspberry', 
      count: 120, // Increased count for "heavy" presence
      weight: 0.6, 
      color: '#E30022', // Highly saturated deep red
      size: 0.14 // Medium volume
    },
  ], []);

  const ornamentInstances = useMemo(() => {
    return categories.map(cat => {
      const data = Array.from({ length: cat.count }).map(() => {
        const u = Math.random();
        const h = u * 6.0;
        const r = (1 - u * 0.9) * 2.6;
        const a = Math.random() * Math.PI * 2;
        
        const treePos = new THREE.Vector3(Math.cos(a) * r, h, Math.sin(a) * r);
        const scatterPos = new THREE.Vector3(
          (Math.random() - 0.5) * 25,
          (Math.random() - 0.5) * 25 + 3,
          (Math.random() - 0.5) * 25
        );
        
        return {
          treePos,
          scatterPos,
          phase: Math.random() * Math.PI * 2,
          scale: Math.random() * 0.3 + 0.85
        };
      });
      return { ...cat, data, ref: React.createRef<THREE.InstancedMesh>() };
    });
  }, [categories]);

  const dummy = new THREE.Object3D();

  useFrame((state, delta) => {
    const targetMorph = config.state === 'TREE_SHAPE' ? 1 : 0;
    morphFactor.current = THREE.MathUtils.lerp(morphFactor.current, targetMorph, delta * 2.0);
    
    if (foliageRef.current) {
      const material = foliageRef.current.material as THREE.ShaderMaterial;
      material.uniforms.uTime.value = state.clock.elapsedTime;
      material.uniforms.uMorph.value = morphFactor.current;
      material.uniforms.uGlow.value = config.glowAmount;
    }

    if (groupRef.current) {
      groupRef.current.rotation.y += 0.003 * config.rotationSpeed * morphFactor.current;
    }

    ornamentInstances.forEach(cat => {
      if (!cat.ref.current) return;
      cat.data.forEach((obj, i) => {
        const currentPos = new THREE.Vector3().lerpVectors(obj.scatterPos, obj.treePos, morphFactor.current);
        const floatMagnitude = (1.0 - morphFactor.current) * (2.0 / (cat.weight + 0.1));
        currentPos.y += Math.sin(state.clock.elapsedTime * 0.5 + obj.phase) * floatMagnitude * 0.2;

        dummy.position.copy(currentPos);
        dummy.scale.setScalar(obj.scale * cat.size * THREE.MathUtils.lerp(0.5, 1, morphFactor.current));
        dummy.rotation.set(
          state.clock.elapsedTime * 0.1 * cat.weight + obj.phase,
          state.clock.elapsedTime * 0.2 * cat.weight,
          0
        );
        dummy.updateMatrix();
        cat.ref.current!.setMatrixAt(i, dummy.matrix);
      });
      cat.ref.current.instanceMatrix.needsUpdate = true;
    });
  });

  return (
    <group ref={groupRef}>
      <points ref={foliageRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={foliageCount} array={foliageAttributes.treePos} itemSize={3} />
          <bufferAttribute attach="attributes-aTreePos" count={foliageCount} array={foliageAttributes.treePos} itemSize={3} />
          <bufferAttribute attach="attributes-aScatterPos" count={foliageCount} array={foliageAttributes.scatterPos} itemSize={3} />
          <bufferAttribute attach="attributes-aSize" count={foliageCount} array={foliageAttributes.sizes} itemSize={1} />
          <bufferAttribute attach="attributes-aOffset" count={foliageCount} array={foliageAttributes.offsets} itemSize={1} />
        </bufferGeometry>
        <shaderMaterial args={[FoliageShader]} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
      </points>

      {ornamentInstances.map(cat => (
        <instancedMesh key={cat.name} ref={cat.ref} args={[undefined, undefined, cat.count]} castShadow>
          {cat.name === 'bauble' ? <sphereGeometry args={[1, 16, 16]} /> : 
           cat.name === 'star' ? <octahedronGeometry args={[1, 0]} /> : 
           cat.name === 'raspberry' ? <icosahedronGeometry args={[1, 1]} /> : // Slightly bumpy for organic raspberry feel
           <boxGeometry args={[1, 1, 1]} />}
          
          <meshPhysicalMaterial 
            color={cat.color} 
            metalness={cat.name === 'raspberry' ? 0.2 : config.goldLustre} 
            roughness={cat.name === 'raspberry' ? 0.5 : 0.1} 
            clearcoat={1.0}
            emissive={cat.color} 
            emissiveIntensity={config.glowAmount * (cat.name === 'raspberry' ? 0.2 : 0.3) * morphFactor.current} 
          />
        </instancedMesh>
      ))}

      <Float speed={4} rotationIntensity={2}>
        <mesh position={[0, 6.8, 0]} scale={morphFactor.current}>
          <octahedronGeometry args={[0.7, 0]} />
          <meshStandardMaterial color={config.starColor} emissive={config.starColor} emissiveIntensity={5 * config.glowAmount} />
          <pointLight intensity={4 * config.glowAmount} color={config.starColor} distance={15} />
        </mesh>
      </Float>

      <Sparkles count={400} scale={20} size={5} speed={1} color="#FFD700" opacity={config.glowAmount * 0.7} />
    </group>
  );
};

export default ChristmasTree;
