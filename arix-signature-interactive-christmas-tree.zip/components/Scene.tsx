
import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { 
  OrbitControls, 
  PerspectiveCamera, 
  Environment, 
  ContactShadows, 
} from '@react-three/drei';
import { EffectComposer, Bloom, Noise, Vignette, ChromaticAberration } from '@react-three/postprocessing';
import ChristmasTree from './ChristmasTree';
import { TreeConfig } from '../types';
import * as THREE from 'three';

interface SceneProps {
  config: TreeConfig;
}

const Scene: React.FC<SceneProps> = ({ config }) => {
  return (
    <Canvas 
      shadows 
      dpr={[1, 2]} 
      gl={{ 
        antialias: true, 
        toneMapping: THREE.ReinhardToneMapping,
        exposure: 1.2
      }}
    >
      <PerspectiveCamera makeDefault position={[0, 4, 14]} fov={40} />
      <OrbitControls 
        enablePan={false} 
        minDistance={8} 
        maxDistance={25} 
        autoRotate={false}
        maxPolarAngle={Math.PI / 1.7}
        minPolarAngle={Math.PI / 4}
      />

      <color attach="background" args={['#000805']} />
      
      <ambientLight intensity={0.2} />
      
      <spotLight 
        position={[15, 20, 10]} 
        angle={0.2} 
        penumbra={1} 
        intensity={3} 
        castShadow 
        color="#fff4e0"
        shadow-mapSize={[2048, 2048]}
      />
      
      <pointLight position={[-15, 5, -10]} intensity={2} color="#059669" />
      <pointLight position={[0, -2, 5]} intensity={1.5} color="#b45309" />

      <Suspense fallback={null}>
        {/* Adjusted Y position from -2.5 to -4.5 to move the tree downwards */}
        <group position={[0, -4.5, 0]}>
          <ChristmasTree config={config} />
          <ContactShadows resolution={1024} scale={20} blur={2.5} opacity={0.5} far={10} color="#000000" />
        </group>
        <Environment preset="night" />
      </Suspense>

      <EffectComposer disableNormalPass>
        <Bloom luminanceThreshold={0.4} mipmapBlur intensity={config.glowAmount * 1.8} radius={0.5} />
        <ChromaticAberration offset={new THREE.Vector2(0.001, 0.001)} />
        <Vignette eskil={false} offset={0.2} darkness={1.2} />
        <Noise opacity={0.03} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;
