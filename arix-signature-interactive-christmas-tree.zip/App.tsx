
import React, { useState } from 'react';
import Scene from './components/Scene';
import UIOverlay from './components/UIOverlay';
import ArixAssistant from './components/ArixAssistant';
import { TreeConfig } from './types';

const App: React.FC = () => {
  const [config, setConfig] = useState<TreeConfig>({
    emeraldIntensity: 0.8,
    goldLustre: 1.0,
    glowAmount: 1.2,
    rotationSpeed: 0.8,
    ornamentDensity: 1.2,
    starColor: '#FFD700',
    state: 'TREE_SHAPE'
  });

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#000503]">
      {/* Subtle Animated Aurora-like Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_rgba(6,78,59,0.15)_0%,_transparent_50%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_0%_100%,_rgba(191,149,63,0.05)_0%,_transparent_40%)] pointer-events-none" />

      {/* 3D Scene */}
      <div className="absolute inset-0 z-0">
        <Scene config={config} />
      </div>

      {/* Interactive UI Layer */}
      <UIOverlay config={config} setConfig={setConfig} />
      
      {/* AI Assistant Drawer */}
      <ArixAssistant config={config} setConfig={setConfig} />

      {/* Master Cinematic Frame Overlay */}
      <div className="absolute inset-0 border-[40px] border-emerald-950/10 pointer-events-none z-50">
        <div className="absolute top-0 left-0 w-40 h-40 border-t-2 border-l-2 border-gold-500/20 m-4 shadow-[-20px_-20px_50px_rgba(191,149,63,0.05)]" />
        <div className="absolute top-0 right-0 w-40 h-40 border-t-2 border-r-2 border-gold-500/20 m-4 shadow-[20px_-20px_50px_rgba(191,149,63,0.05)]" />
        <div className="absolute bottom-0 left-0 w-40 h-40 border-b-2 border-l-2 border-gold-500/20 m-4 shadow-[-20px_20px_50px_rgba(191,149,63,0.05)]" />
        <div className="absolute bottom-0 right-0 w-40 h-40 border-b-2 border-r-2 border-gold-500/20 m-4 shadow-[20px_20px_50px_rgba(191,149,63,0.05)]" />
      </div>

      {/* Loading Hint / UX Detail */}
      <div className="absolute bottom-8 left-10 pointer-events-none animate-pulse">
        <p className="text-[9px] text-gold-500/40 uppercase tracking-[1em]">Celestial Synchronized</p>
      </div>
    </div>
  );
};

export default App;
