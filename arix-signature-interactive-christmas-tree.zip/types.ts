
export type TreeState = 'SCATTERED' | 'TREE_SHAPE';

export interface TreeConfig {
  emeraldIntensity: number;
  goldLustre: number;
  glowAmount: number;
  rotationSpeed: number;
  ornamentDensity: number;
  starColor: string;
  state: TreeState;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}
